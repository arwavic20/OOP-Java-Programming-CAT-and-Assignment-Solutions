/*Write a Java program that takes 15 values of type integer as inputs from user, store the values in an array.
a)	Print the values stored in the array on screen.
b)	 Ask user to enter a number, check if that number (entered by user) is present in array or not. If it is present print, “the number found at index (index of the number) ” and the text “number not found in this array”
c)	Sort the arrays in ascending order.
d)	Create another array, copy all the elements from the existing array to the new array but in reverse order. Now print the elements of the new array on the screen
*/
import java.util.Scanner;
import jav

public class ArraysOperations {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int[] array = new int[15];

        // a) Input 15 values into the array
        System.out.println("Enter 15 integers:");
        for (int i = 0; i < array.length; i++) {
            array[i] = scanner.nextInt();
        }

        // b) Print the values stored in the array
        System.out.println("Values in the array:");
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();

        // c) Ask user for a number and check if it is in the array
        System.out.print("Enter a number to search in the array: ");
        int numberToFind = scanner.nextInt();
        boolean found = false;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == numberToFind) {
                System.out.println("The number " + numberToFind + " found at index " + i);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Number not found in this array.");
        }

        // d) Sort the array in ascending order
        Arrays.sort(array);
        System.out.println("Array sorted in ascending order:");
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();

        // e) Copy elements to a new array in reverse order
        int[] reversedArray = new int[array.length];
        for (int i = 0; i < array.length; i++) {
            reversedArray[i] = array[array.length - 1 - i];
        }
        System.out.println("Reversed array:");
        for (int value : reversedArray) {
            System.out.print(value + " ");
        }
        System.out.println();

        scanner.close();
    }
}