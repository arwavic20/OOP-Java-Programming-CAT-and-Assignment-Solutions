/*A palindrome number is a number that remain the same when read from behind or
front  ( a number that is equal to reverse of number) for example,  353 is palindrome
because reverse of 353 is 353 (you see the number remains the same). But a number
like 591 is not palindrome because reverse of 591 is 195 which is not equal to 591.
Write Java program to check if a number entered by the user is palindrome or not.
You should provide the user with a GUI interface to enter the number and display
the results on the same interface.
 */

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PalindromeChecker {

    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("Palindrome Checker");
        frame.setSize(400, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Create a label for instructions
        JLabel label = new JLabel("Enter a number:");
        label.setBounds(50, 20, 150, 25);
        frame.add(label);

        // Create a text field for user input
        JTextField textField = new JTextField();
        textField.setBounds(150, 20, 200, 25);
        frame.add(textField);

        // Create a button to check the palindrome
        JButton checkButton = new JButton("Check");
        checkButton.setBounds(150, 60, 100, 25);
        frame.add(checkButton);

        // Create a label to display the result
        JLabel resultLabel = new JLabel("");
        resultLabel.setBounds(50, 100, 300, 25);
        frame.add(resultLabel);

        // Add action listener to the button
        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = textField.getText();
                if (isPalindrome(input)) {
                    resultLabel.setText(input + " is a palindrome.");
                } else {
                    resultLabel.setText(input + " is not a palindrome.");
                }
            }
        });

        // Set the frame visibility
        frame.setVisible(true);
    }

    // Method to check if a number is a palindrome
    public static boolean isPalindrome(String number) {
        int left = 0;
        int right = number.length() - 1;

        while (left < right) {
            if (number.charAt(left) != number.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}