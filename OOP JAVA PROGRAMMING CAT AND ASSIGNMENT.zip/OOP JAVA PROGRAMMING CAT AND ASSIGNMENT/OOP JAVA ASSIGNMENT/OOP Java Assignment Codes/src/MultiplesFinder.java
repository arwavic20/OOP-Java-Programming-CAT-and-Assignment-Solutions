//4.	Write a Java program to display all the multiples of 2, 3 and 7 within the range 71 to 150.
public class MultiplesFinder {
    public static void main(String[] args) {

        //initializing 71 as the lower bound and 150 as the upper bound
        int lowerBound = 71;
        int upperBound = 150;

        System.out.println("Multiples of 2, 3, and 7 between " + lowerBound + " and " + upperBound + ":");

        //looping between the numbers between 71 and 50 to test the multiplicity
        for (int i = lowerBound; i <= upperBound; i++) {
            if (i % 2 == 0 && i % 3 == 0 && i % 7 == 0) {
                System.out.println(i);
            }
        }
    }
}