/*2.	Write Java program to ask student to enter the marks of the five units they
 did last semester, compute the average and display it on the screen.
 (Average should be given in two decimal places).
 */
import java.util.Scanner;

public class AverageMarks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Array to hold marks for 5 units
        double[] marks = new double[5];
        double total = 0.0;

        // Asking user to enter marks
        System.out.println("Enter the marks for 5 units:");

        //for loop to take in the marks and store the values entered

        for (int i = 0; i < 5; i++) {
            System.out.print("Unit " + (i + 1) + ": ");
            // Read mark for each unit
            marks[i] = scanner.nextDouble();
            total = total + marks[i];
        }

        // Compute average for the five marks entered
        double avg = total / 5;

        // Display average with two decimal places
        System.out.printf("The average mark is: %.2f%n", avg);

        // Closing the scanner
        scanner.close();
    }
}