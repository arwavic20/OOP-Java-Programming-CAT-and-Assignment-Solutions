/*1.	Write a Java program that asks the user to enter their surname and current age then print the number of characters of their surname and even or odd depending on their age number.
Example of Expected result:
If sir name is Saruni and age is 29, output will be:
then the number of characters is 6.
Your current age is an odd number*/


import java.util.Scanner;

public class Surname{


    //the main method
    public static void main(String[] args)
    {
        // Create a Scanner object for input using the scanner class
        Scanner scanner = new Scanner(System.in);

        //Asking the user for their surname
        System.out.println("Please enter your surname: ");
        String surname = scanner.nextLine();

        //asking the student for their age
        System.out.println("Please enter your age: ");
        int age = scanner.nextInt();

        // Calculate the number of characters in the surname entered by the user.
        int countSurnamecharacters = surname.length();

        System.out.println("The number of characters in your name is: " + countSurnamecharacters);

        //using if else statement to determine whether the age of the user is odd or even
        if (age % 2 == 0)
        {
            System.out.println("Your current age is an even number.");
        }
        else
        {
            System.out.println("Your current age is an odd number.");
        }

    }
}